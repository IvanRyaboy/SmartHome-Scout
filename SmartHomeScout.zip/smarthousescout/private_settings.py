SECRET_KEY = 'django-insecure-6c%^((bmv7te8yhrh=om40!j4*ogj04!yz*q93way0kc7w$(mj'

DEBUG = True
